<?php
  // If this file is called directly, abort
  if ( ! defined('ABSPATH') ) {
    die;
  }
?>
<input type="text" name="cb_option[quandl_api_key]" value="%%quandl_api_key%%">