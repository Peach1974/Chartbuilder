<?php
  // If this file is called directly, abort
  if ( ! defined('ABSPATH') ) {
    die;
  }
?>
<input type="text" name="cb_option[cache_time]" value="%%cache_time%%">
<p class="description">Cache time must be in minutes.</p>